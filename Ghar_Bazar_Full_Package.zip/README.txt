घर बाजार वेबसाइट पैकेज

GitHub में upload करें:
1. index.html
2. logo.png (अगर मौजूद है)
3. images folder

नोट: मौजूदा index.html के product image links online images पर हैं।
images folder में 27 local fallback/placeholder assets भी हैं।
